package com.scada.service;

import com.scada.entities.FaultValidationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class FaultService {

    @Autowired
    private FaultConfigService configService;

    // ----------------------------------------------------
    // MAIN VALIDATION ENTRY
    // ----------------------------------------------------
    public FaultValidationResponse validateFaultResolution(String faultLine, List<String> seq) {
        System.err.println("User Sequence: " + seq);

        // ---------------- LG7 ----------------
        if (faultLine.equals("LG7")) {
            String series = detectSeriesLG7(seq);
            if (series == null) return new FaultValidationResponse(false, "❌ Could not detect LG7 series");
            Map<String, List<String>> blocks = configService.getFlexConfig("LG7", series);
            if (blocks == null) return new FaultValidationResponse(false, "❌ No LG7 config found");

            boolean ok = validateLG7(seq, blocks, series);
            return new FaultValidationResponse(ok, ok ? "✅ Fault resolved properly" : "⚠️ Fault resolved but not in proper way");
        }

        // ---------------- LG8 ----------------
        if (faultLine.equals("LG8")) {
            String series = detectSeriesLG8(seq);
            if (series == null) return new FaultValidationResponse(false, "❌ Could not detect LG8 series");
            Map<String, List<String>> blocks = configService.getFlexConfig("LG8", series);
            if (blocks == null) return new FaultValidationResponse(false, "❌ No LG8 config found");

            boolean ok = validateLG8(seq, blocks, series);
            return new FaultValidationResponse(ok, ok ? "✅ Fault resolved properly" : "⚠️ Fault resolved but not in proper way");
        }

        // ---------------- LG11 ----------------
        if (faultLine.equals("LG11")) {
            String series = detectSeriesLG11(seq);
            if (series == null) return new FaultValidationResponse(false, "❌ Could not detect LG11 series");
            Map<String, List<String>> blocks = configService.getFlexConfig("LG11", series);
            if (blocks == null) return new FaultValidationResponse(false, "❌ No LG11 config found");

            boolean ok = validateLG11(seq, blocks, series);
            return new FaultValidationResponse(ok, ok ? "✅ Fault resolved properly" : "⚠️ Fault resolved but not in proper way");
        }

        // ---------------- LG12 ----------------
        if (faultLine.equals("LG12")) {
            String series = detectSeriesLG12(seq);
            if (series == null) return new FaultValidationResponse(false, "❌ Could not detect LG12 series");

            boolean ok = validateLG12(seq, series);
            return new FaultValidationResponse(ok, ok ? "✅ Fault resolved properly" : "⚠️ Fault resolved but not in proper way");
        }

        // ---------------- LG24 ----------------
        if (faultLine.equals("LG24")) {

            String variant = detectLG24Variant(seq); // RS17 or RS15
            if (variant == null) {
                return new FaultValidationResponse(false,
                        "❌ Could not detect RS15/RS17 variant for LG24");
            }

            boolean ok;
            if (variant.equals("RS17")) {
                ok = validateLG24_RS17(seq);
            } else {
                ok = validateLG24_RS15(seq);
            }

            return new FaultValidationResponse(
                    ok,
                    ok ? "✅ Fault resolved properly" : "⚠️ Fault resolved but not in proper way"
            );
        }

        return new FaultValidationResponse(false, "❌ Validation not implemented for " + faultLine);
    }

    // ====================================================
    // LG24 HELPERS
    // ====================================================

    private String detectLG24Variant(List<String> seq) {
        if (seq.contains("RS17")) return "RS17";
        if (seq.contains("RS15")) return "RS15";
        return null;
    }

    private boolean validateLG24_RS17(List<String> seq) {
        int index = 0;

        if (!matchLG24Start(seq, index, "RS17")) return false;
        index += 5;

        if (!matchLG24Middle_RS17(seq, index)) return false;
        index += 3;

        return matchLG24End(seq, index);
    }

    private boolean validateLG24_RS15(List<String> seq) {
        int index = 0;

        if (!matchLG24Start(seq, index, "RS15")) return false;
        index += 5;

        return matchLG24End(seq, index);
    }

    private boolean matchLG24Start(List<String> seq, int index, String variant) {
        if (index + 5 > seq.size()) return false;

        if (!seq.get(index).equals("RS18")) return false;

        Set<String> expected = Set.of(
                "RS18", variant, "RS38", "RS26", "RS45"
        );

        return new HashSet<>(seq.subList(index, index + 5)).equals(expected);
    }

    private boolean matchLG24Middle_RS17(List<String> seq, int index) {
        if (index + 3 > seq.size()) return false;

        if (!seq.get(index).equals("RS18")) return false;

        Set<String> expected = Set.of("RS15", "RS17");
        Set<String> actual = Set.of(seq.get(index + 1), seq.get(index + 2));

        return expected.equals(actual);
    }

    private boolean matchLG24End(List<String> seq, int index) {
        int rem = seq.size() - index;
        if (rem < 5) return false;

        String a = seq.get(index);
        String b = seq.get(index + 1);
        String c = seq.get(index + 2);
        String d = seq.get(index + 3);
        String e = seq.get(index + 4);

        if (!a.equals("RS18")) return false;
        if (!b.equals("RS37")) return false;
        if (!(c.equals("RS38") || c.equals("RS45"))) return false;
        if (!d.equals("RS25")) return false;
        if (!e.equals("RS26")) return false;

        for (int i = index + 5; i < seq.size(); i++) {
            String s = seq.get(i);
            if (!(s.equals("RS37") || s.equals("RS38") || s.equals("RS45"))) return false;
        }

        return true;
    }

    // ====================================================
    // Existing LG7, LG8, LG11, LG12 (unchanged)
    // ====================================================

    private String detectSeriesLG7(List<String> seq) {
        if (seq.size() < 4) return null;
        List<String> start = seq.subList(0, 4);
        if (start.contains("RS6")) return "SERIES1";
        if (start.contains("RS16")) return "SERIES2";
        return null;
    }

    private boolean validateLG7(List<String> seq, Map<String, List<String>> blocks, String series) {
        int index = 0;

        if (!matchFlexible(seq, index, blocks.get("START"))) return false;
        index += blocks.get("START").size();

        if (series.equals("SERIES1")) {
            if (!matchLG7Series1Middle(seq, index)) return false;
            index += 5;
        } else {
            if (!matchExact(seq, index, blocks.get("MIDDLE"))) return false;
            index += blocks.get("MIDDLE").size();
        }

        if (!matchLG7End(seq, index)) return false;
        index += 5;

        return index == seq.size();
    }

    private boolean matchLG7Series1Middle(List<String> seq, int index) {
        if (index + 5 > seq.size()) return false;

        String a = seq.get(index);
        String x = seq.get(index + 1);
        String y = seq.get(index + 2);
        String b = seq.get(index + 3);
        String c = seq.get(index + 4);

        if (!a.equals("RS8")) return false;
        if (!b.equals("RS8")) return false;
        if (!c.equals("RS14")) return false;

        return Set.of(x, y).equals(Set.of("RS6", "RS16"));
    }

    private boolean matchLG7End(List<String> seq, int index) {
        if (index + 5 > seq.size()) return false;

        String A = seq.get(index);
        String mid = seq.get(index + 1);
        String B = seq.get(index + 2);
        String C = seq.get(index + 3);
        String last = seq.get(index + 4);

        if (!mid.equals("RS8") || !last.equals("RS8")) return false;
        if (!(A.equals("RS4") || A.equals("RS12"))) return false;

        return Set.of(B, C).equals(Set.of(A, "RS16"));
    }

    private String detectSeriesLG8(List<String> seq) {
        if (seq.size() < 4) return null;
        List<String> start = seq.subList(0, 4);
        if (start.contains("RS6")) return "SERIES1";
        if (start.contains("RS16")) return "SERIES2";
        return null;
    }

    private boolean validateLG8(List<String> seq, Map<String, List<String>> blocks, String series) {
        int index = 0;

        if (!matchFlexible(seq, index, blocks.get("START"))) return false;
        index += blocks.get("START").size();

        if (series.equals("SERIES1")) {
            if (!matchExact(seq, index, blocks.get("MIDDLE"))) return false;
            index += blocks.get("MIDDLE").size();
        } else {
            if (!matchLG8Series2Middle(seq, index)) return false;
            index += 5;
        }

        if (!matchLG8End(seq, index, blocks.get("END"))) return false;
        index += blocks.get("END").size();

        return index == seq.size();
    }

    private boolean matchLG8Series2Middle(List<String> seq, int index) {
        if (index + 5 > seq.size()) return false;

        String a = seq.get(index);
        String x = seq.get(index + 1);
        String y = seq.get(index + 2);
        String b = seq.get(index + 3);
        String c = seq.get(index + 4);

        if (!a.equals("RS8") || !b.equals("RS8") || !c.equals("RS5")) return false;

        return Set.of(x, y).equals(Set.of("RS6", "RS16"));
    }

    private boolean matchLG8End(List<String> seq, int index, List<String> end) {
        if (index + 5 > seq.size()) return false;

        String A1 = seq.get(index);
        String mid = seq.get(index + 1);
        String A2 = seq.get(index + 2);
        String B = seq.get(index + 3);
        String last =
